<?php

  function GetAllBirthday(){
  	$db = openDatabaseConnection();
    $sql = "SELECT * FROM birthdays ORDER BY  month , day , year ASC";
    $query = $db->prepare($sql);
  	$query->execute();
  	$db = null;
  	return $query->fetchAll();
  }



 function createBirthday(){
   $person = ($_post['person']);
   $day = ($_post['day']);
   $month = ($_post['month']);
   $year = ($_post['year']);

   $db = openDatabaseConnection();

   $sql = "INSERT INTO calender(person, day, month, year) VALUES(:person, :day, :month, :year)";
   $query = $db->prepare($sql);
   $query->execute(array(
     ':person' => $person,
     ':day' => $day,
     ':month' => $month,
     ':year' => $year,));
     ;

   $db = null;
   return true;


 }









?>
