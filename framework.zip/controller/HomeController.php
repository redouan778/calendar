<?php

function index()
{
	render("index");
}
