
<?php

  require(ROOT . "model/calenderModel.php");


  function index(){
    echo "Aanroep CalendarController";

    $data = GetAllBirthday();

    render("calender/index", $data);
  }

  function toevoegen(){
  	render("calender/toevoegen");
  }


  function edit(){
    render("calender/edit");
  }

?>
