  <footer>
    <p>&copy; Made by Redouan Sellami </p>
  </footer>

</body>
</html>
